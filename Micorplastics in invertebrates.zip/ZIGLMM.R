library(lme4)
library(glmm.hp)
library(MCMCglmm)
library(MuMIn)
library(tidyverse)
library(dplyr)
library(factoextra)
library(glmmTMB)
library(DHARMa)
library(ggplot2)
library(gridExtra)
library(psych)


data <- read.csv("method.csv")

data <- na.omit(data)

data <- data %>%mutate(score2 = factor(score2))

##########################################  PCA 
selected_vars <- data[, c("x10", "x11", "x21", "x101", "x201", "x500", 
                          "Predator", "Parasite", "Surface_deposit", 
                          "Herbivore", "Suspension", "Scavenger", "Shredder")]
pca_result <- prcomp(selected_vars, rank. = 3)
pca_scores <- as.data.frame(pca_result$x[, 1:3])
colnames(pca_scores) <- c("PC1", "PC2", "PC3")
head(pca_scores)
summary(pca_result)

theme_set(theme_minimal(base_size = 10))
# function
create_var_plot <- function(pca_result, axes, title) {
  fviz_pca_var(
    pca_result,
    axes = axes,               
    geom = "auto",              
    geom.var = c("arrow", "text"), 
    col.var = "contrib",        # 颜色与变量贡献度关联
    gradient.cols = c("#2E9FDF", "#E7B800", "#FC4E07"),  
    repel = TRUE,               
    arrowsize = 1,              
    labelsize = 4,              
    title = title               
  ) +
    labs(x = paste0("PC", axes[1]), y = paste0("PC", axes[2])) +  
    theme(
      plot.title = element_text(hjust = 0.5, face = "bold"),  
      legend.position = "bottom"             
    )
}

pca_plot1 <- create_var_plot(pca_result, axes = c(1,2), "Variables - PC1 vs PC2")
pca_plot2 <- create_var_plot(pca_result, axes = c(1,3), "Variables - PC1 vs PC3")
pca_plot3 <- create_var_plot(pca_result, axes = c(2,3), "Variables - PC2 vs PC3")

combined_plot <- grid.arrange(
  plot12, plot13, plot23,
  nrow = 2, ncol = 2, 
  layout_matrix = rbind(c(1, 2), c(3, NA))  
)


###################################extract PCA
data$PC1 <- pca_result$x[,1]
data$PC2 <- pca_result$x[,2]
data$PC3 <- pca_result$x[,3]


# ####################################################################################################GAMA distribution
glmm_gamma1 <- glmmTMB(MP ~ Environment2 + Continent +  PC1 + PC2 + PC3 +  (1|score2) + (1|Order), 
                       family = Gamma(link = "log"), data = data)

glmm_gamma2 <- glmmTMB(MP ~ Environment2 + Continent +  PC1 + PC2 + PC3 + + scale(Abund) + (1|score2) + (1|Order), 
                       family = Gamma(link = "log"), data = data)

glmm_gamma3 <- glmmTMB(MP ~ Environment2 + Continent +  PC1 + PC2 + PC3 + + scale(size) + (1|score2) + (1|Order), 
                       family = Gamma(link = "log"), data = data)

glmm_gamma4 <- glmmTMB(MP ~ Environment2 + Continent + scale(Abund) + PC1 + PC2 + PC3 + scale(size) + (1|score2) + (1|Order), 
                       family = Gamma(link = "log"), data = data)  


res <- simulateResiduals(glmm_gamma4, n=1000)


testDispersion(res) 
testZeroInflation(res) 
plot(res)
summary(glmm_gamma4) 
r.squaredGLMM(glmm_gamma4) 
AIC(glmm_gamma1, glmm_gamma2, glmm_gamma3, glmm_gamma4) 


####################################################################################### Gaussian distribution

shapiro.test(log(data$MP))  

qqline(log(data$MP))

glmer_gaussian1 <- lmer(log(MP) ~ Environment2 + Continent + PC1 + PC2 + PC3 + (1|score2) + (1|Order), data = data)

glmer_gaussian2 <- lmer(log(MP) ~ Environment2 + Continent + PC1 + PC2 + PC3 + scale(size) + (1|score2) + (1|Order), data = data)

glmer_gaussian3 <- lmer(log(MP) ~ Environment2 + Continent + scale(Abund) + PC1 + PC2 + PC3 + (1|score2) + (1|Order), data = data)

glmer_gaussian4 <- lmer(log(MP) ~ Environment2 + Continent + scale(Abund) + PC1 + PC2 + PC3 + scale(size) + (1|score2) + (1|Order), data = data)

AIC(glmer_gaussian1, glmer_gaussian2, glmer_gaussian3, glmer_gaussian4)

summary(glmer_gaussian4) 
r.squaredGLMM(glmer_gaussian) 

mcmc <- MCMCglmm(fixed=log(MP) ~ Environment2 + Continent + scale(Abund) + PC1 + PC2 + PC3+ scale(size),random=~score2+Order, data = data) # estimating p value for correlated random effects 
summary(mcmc) 

res_gau <- simulateResiduals(glmer_gaussian4, n=1000)
testDispersion(res_gau) 
testZeroInflation(res_gau) 
plot(res_gau)
