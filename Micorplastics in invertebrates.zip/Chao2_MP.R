library(vegan)
library(iNEXT)
library(ggplot2)
library(ggbreak)
library(dplyr)
library(patchwork)
library(cowplot)
library(ggpubr)
library(iNEXT.4steps)

########################################################################################################################taxa level
########################################################################################################## all sites
all_sp<-read.csv("all_sp.csv",header = T,row.names = 1)
all_sp<-decostand(all_sp,method='pa') 
all_sp2<-as.incfreq(all_sp)
richness_all_sp<-iNEXT(all_sp2,q=0,datatype = "incidence_freq")

#################################Fig.4A
gg.all_sp1<-ggiNEXT(richness_all_sp,type = 1,se=TRUE,color.var = "Order.q", grey=T)+
  theme_classic()+
  geom_hline(yintercept = 598.70027 , linetype="dotdash",size=1.5)+ 
  labs(y="Taxonomic Richness")+
  theme(text = element_text(size = 25, family="serif"),
        axis.text = element_text(size = 23, family="serif",color = 'black'),
        panel.border = element_rect(fill = NA, colour = "black",size = 1),
        legend.position = "none")
############## The value of "yintercept" comes from results of "richness_all_sp": estimated species richness
############## All of the following are similar

#################################Fig.4B
gg.all_sp2<-ggiNEXT(richness_all_sp,type = 2,se=TRUE,color.var = "Order.q", grey=T)+
  theme_classic()+
  labs(x="Number of Sampling sites")+
  theme(text = element_text(size = 25, family="serif"),
        axis.text = element_text(size = 23, family="serif",color = 'black'),
        panel.border = element_rect(fill = NA, colour = "black",size = 1),
        legend.position = "none") 

#################################Fig.4C
main<-iNEXT4steps(all_sp2,q = seq(0, 2, 0.2),datatype = "incidence_freq") ###(c) == Fig.4C

####################################################################################################### continent
continent_sp<-read.csv("continent_sp.csv",header = T)
richness_continent_sp<-iNEXT(continent_sp,q=0,datatype = "incidence_freq")

#################################Fig.4D
gg.continent_sp1<-ggiNEXT(richness_continent_sp,type = 1,se=T,color.var = "Assemblage", grey=FALSE)+
  theme_classic()+
  geom_hline(yintercept = 65 , linetype="dotdash", colour="#cc79a7",size=1.5)+ ## north America
  geom_hline(yintercept = 156.72  , linetype="dotdash", colour="#d55e00",size=1.5)+  ##Asia
  geom_hline(yintercept = 265.89  , linetype="dotdash", colour="#0072b2",size=1.5)+  ##Europe
  #geom_hline(yintercept = 35, linetype="dotdash", colour="#d55e00",size=1.5)+ ##Africa
  labs(y=" ")+
  theme(text = element_text(size = 25, family="serif"),
        axis.text = element_text(size = 23, family="serif",color = 'black'),
        panel.border = element_rect(fill = NA, colour = "black",size = 1),
        axis.line.y.right = element_blank(),
        axis.text.y.right = element_blank(),
        axis.ticks.y.right = element_blank(),legend.position = "none")+
  #scale_y_break(c(200,270),ticklabels=c(212, 274, 312))+
  ylim(0, 290)

#################################Fig.4E
gg.continent_sp2<-ggiNEXT(richness_continent_sp,type = 2,se=T,color.var = "Assemblage", grey=FALSE)+
  theme_classic()+
  labs(x="Number of Sampling sites")+
  theme(text = element_text(size = 25, family="serif"),
        axis.text = element_text(size = 23, family="serif",color = 'black'),
        panel.border = element_rect(fill = NA, colour = "black",size = 1),
        axis.line.y.right = element_blank(),
        axis.text.y.right = element_blank(),
        axis.ticks.y.right = element_blank(),legend.position = "none")

#################################Fig.4F
main_2<-iNEXT4steps(continent_sp,q = seq(0, 2, 0.2),datatype = "incidence_freq")###(c) == Fig.4F

##################################################################################################  aquatic environments
water_sp<-read.csv("water_sp.csv",header = T)
richness_water_sp<-iNEXT(water_sp,q=0,datatype = "incidence_freq")

#################################Fig.4G
gg.water_sp1<-ggiNEXT(richness_water_sp,type = 1,se=T,color.var = "Assemblage", grey=FALSE)+
  theme_classic()+
  geom_hline(yintercept = 151  , linetype="dotdash", colour="#cc79a7",size=1.5)+ ## river
  geom_hline(yintercept = 155 , linetype="dotdash", colour="#0072b2",size=1.5)+  ##Coast
  geom_hline(yintercept = 527  , linetype="dotdash", colour="#d55e00",size=1.5)+ ##Bay
  #geom_hline(yintercept = 41   , linetype="dotdash", colour="#009e73",size=1.5)+ ##Sea
  labs(y=" ")+
  theme(text = element_text(size = 25, family="serif"),
        axis.text = element_text(size = 23, family="serif",color = 'black'),
        panel.border = element_rect(fill = NA, colour = "black",size = 1),
        axis.line.y.right = element_blank(),
        axis.text.y.right = element_blank(),
        axis.ticks.y.right = element_blank(),legend.position = "none")+
  scale_y_break(c(160,510),ticklabels=c(520))+
  ylim(0,530)


#################################Fig.4H
gg.water_sp2<-ggiNEXT(richness_water_sp,type = 2,se=T,color.var = "Assemblage", grey=FALSE)+
  theme_classic()+
  labs(x="Number of Sampling sites")+
  theme(text = element_text(size = 25, family="serif"),
        axis.text = element_text(size = 23, family="serif",color = 'black'),
        panel.border = element_rect(fill = NA, colour = "black",size = 1),
        axis.line.y.right = element_blank(),
        axis.text.y.right = element_blank(),
        axis.ticks.y.right = element_blank(),legend.position = "none")

#################################Fig.4I
main_3<-iNEXT4steps(water_sp,q = seq(0, 2, 0.2),datatype = "incidence_freq")###(c)---Fig.4I


########################################################################################################################family level
########################################################################################################## all sites
all_fam<-read.csv("all_fam.csv",header = T,row.names = 1)
all_fam<-decostand(all_fam,method='pa') 
all_fam2<-as.incfreq(all_fam)
richness_all_fam<-iNEXT(all_fam2,q=0,datatype = "incidence_freq")

#################################Fig.S2A
gg.all_fam1<-ggiNEXT(richness_all_fam,type = 1,se=TRUE,color.var = "Order.q", grey=T)+
  theme_classic()+
  geom_hline(yintercept = 244.66782  , linetype="dotdash",size=1.5)+
  labs(y="Family richness")+
  labs(x=" ")+
  theme(text = element_text(size = 25, family="serif"),
        axis.text = element_text(size = 23, family="serif",color = 'black'),
        panel.border = element_rect(fill = NA, colour = "black"),
        legend.position = "none")

#################################Fig.S2B
gg.all_fam2<-ggiNEXT(richness_all_fam,type = 2,se=TRUE,color.var = "Order.q", grey=T)+
  theme_classic()+
  labs(x="Number of Sampling sites")+
  theme(text = element_text(size = 25, family="serif"),
        axis.text = element_text(size = 23, family="serif",color = 'black'),
        panel.border = element_rect(fill = NA, colour = "black"),
        legend.position = "none")

#################################Fig.S2C
main_fam<-iNEXT4steps(all_fam2,q = seq(0, 2, 0.2),datatype = "incidence_freq")


########################################################################################################## continent
continent_fam<-read.csv("continent_fam.csv",header = T)
richness_continent_fam<-iNEXT(continent_fam,q=0,datatype = "incidence_freq")

#################################Fig.S2D
gg.continent_fam1<-ggiNEXT(richness_continent_fam,type = 1,se=T,color.var = "Assemblage", grey=FALSE)+
  theme_classic()+
  geom_hline(yintercept = 33.903 , linetype="dotdash", colour="#cc79a7",size=1.5)+ ## north America
  geom_hline(yintercept = 62.982  , linetype="dotdash", colour="#d55e00",size=1.5)+  ##Asia
  geom_hline(yintercept = 158.861  , linetype="dotdash", colour="#0072b2",size=1.5)+  ##Europe
  #geom_hline(yintercept = 35, linetype="dotdash", colour="#d55e00",size=1.5)+ ##Africa
  labs(y="Family richness")+  
  labs(x=" ")+
  theme(text = element_text(size = 25, family="serif"),
        axis.text = element_text(size = 23, family="serif",color = 'black'),
        panel.border = element_rect(fill = NA, colour = "black"),
        axis.line.y.right = element_blank(),
        axis.text.y.right = element_blank(),
        axis.ticks.y.right = element_blank(),legend.position = "none")+
  ylim(0, 160)

#################################Fig.S2E
gg.continent_fam1<-ggiNEXT(richness_continent_fam,type = 2,se=T,color.var = "Assemblage", grey=FALSE)+
  theme_classic()+
  labs(x="Number of Sampling sites")+
  theme(text = element_text(size = 25, family="serif"),
        axis.text = element_text(size = 23, family="serif",color = 'black'),
        panel.border = element_rect(fill = NA, colour = "black"),
        axis.line.y.right = element_blank(),
        axis.text.y.right = element_blank(),
        axis.ticks.y.right = element_blank(),legend.position = "none")

#################################Fig.S2F
main_fam_2<-iNEXT4steps(continent_fam,q = seq(0, 2, 0.2),datatype = "incidence_freq")

##########################################################################################################  aquatic environment
water_fam<-read.csv("water_family.csv",header = T)
richness_water_fam<-iNEXT(water_fam,q=0,datatype = "incidence_freq")

#################################Fig.S2G
gg.water_fam1<-ggiNEXT(richness_water_fam,type = 1,se=T,color.var = "Assemblage", grey=FALSE)+
  theme_classic()+
  geom_hline(yintercept = 66.79687  , linetype="dotdash", colour="#cc79a7",size=1.5)+ ## river
  geom_hline(yintercept = 143.396 , linetype="dotdash", colour="#0072b2",size=1.5)+  ##Coast
  geom_hline(yintercept = 143.607  , linetype="dotdash", colour="#d55e00",size=1.5)+ ##Bay
  #geom_hline(yintercept = 41   , linetype="dotdash", colour="#009e73",size=1.5)+ ##Sea
  labs(y="Family richness")+  
  labs(x=" ")+
  theme(text = element_text(size = 25, family="serif"),
        axis.text = element_text(size = 23, family="serif",color = 'black'),
        panel.border = element_rect(fill = NA, colour = "black"),
        axis.line.y.right = element_blank(),
        axis.text.y.right = element_blank(),
        axis.ticks.y.right = element_blank(),legend.position = "none")

#################################Fig.S2H
gg.water_fam2<-ggiNEXT(richness_water_fam,type = 2,se=T,color.var = "Assemblage", grey=FALSE)+
  theme_classic()+
  labs(x="Number of Sampling sites")+
  theme(text = element_text(size = 25, family="serif"),
        axis.text = element_text(size = 23, family="serif",color = 'black'),
        panel.border = element_rect(fill = NA, colour = "black",size = 1),
        axis.line.y.right = element_blank(),
        axis.text.y.right = element_blank(),
        axis.ticks.y.right = element_blank(),legend.position = "none")

#################################Fig.S2I
main_fam_3<-iNEXT4steps(water_fam,q = seq(0, 2, 0.2),datatype = "incidence_freq")

########################################################################################################################genus level
########################################################################################################## all sites
all_gen<-read.csv("all_gen.csv",header = T,row.names = 1)
all_gen<-decostand(all_gen,method='pa') 
all_gen2<-as.incfreq(all_gen)
richness_all_gen<-iNEXT(all_gen2,q=0,datatype = "incidence_freq")

#################################Fig.S3A
gg.all_gen1<-ggiNEXT(richness_all_gen,type = 1,se=TRUE,color.var = "Order.q", grey=T)+
  theme_classic()+
  geom_hline(yintercept = 177.02441  , linetype="dotdash",size=1.5)+
  labs(y="Genus richness")+
  labs(x=" ")+
  theme(text = element_text(size = 25, family="serif"),
        axis.text = element_text(size = 23, family="serif",color = 'black'),
        panel.border = element_rect(fill = NA, colour = "black",size = 1),
        legend.position = "none")

#################################Fig.S3B
gg.all_gen2<-ggiNEXT(richness_all_gen,type = 2,se=TRUE,color.var = "Order.q", grey=T)+
  theme_classic()+
  labs(x="Number of sampling sites")+
  theme(text = element_text(size = 25, family="serif"),
        axis.text = element_text(size = 23, family="serif",color = 'black'),
        panel.border = element_rect(fill = NA, colour = "black"),
        legend.position = "none") 

#################################Fig.S3C
main_gen<-iNEXT4steps(all_gen2,q = seq(0, 2, 0.2),datatype = "incidence_freq")

########################################################################################################## continent
continent_gen<-read.csv("continent_gen.csv",header = T)
richness_continent_gen<-iNEXT(continent_gen,q=0,datatype = "incidence_freq")

#################################Fig.S3D
gg.continent_gen1<-ggiNEXT(richness_continent_gen,type = 1,se=T,color.var = "Assemblage", grey=FALSE)+
  theme_classic()+
  geom_hline(yintercept = 52.6 , linetype="dotdash", colour="#cc79a7",size=1.5)+ ## north America
  geom_hline(yintercept = 123.1428  , linetype="dotdash", colour="#d55e00",size=1.5)+  ##Asia
  geom_hline(yintercept = 229.27692  , linetype="dotdash", colour="#0072b2",size=1.5)+  ##Europe
  #geom_hline(yintercept = 35, linetype="dotdash", colour="#d55e00",size=1.5)+ ##Africa
  labs(y="Genus richness")+
  labs(x=" ")+  
  theme(text = element_text(size = 25, family="serif"),
        axis.text = element_text(size = 23, family="serif",color = 'black'),
        panel.border = element_rect(fill = NA, colour = "black",size = 1),
        axis.line.y.right = element_blank(),
        axis.text.y.right = element_blank(),
        axis.ticks.y.right = element_blank(),legend.position = "none")+
  #scale_y_break(c(200,270),ticklabels=c(212, 274, 312))+
  ylim(0, 230)

#################################Fig.S3E
gg.continent_gen2<-ggiNEXT(richness_continent_gen,type = 2,se=T,color.var = "Assemblage", grey=FALSE)+
  theme_classic()+
  labs(x="Number of sampling sites")+
  theme(text = element_text(size = 25, family="serif"),
        axis.text = element_text(size = 23, family="serif",color = 'black'),
        panel.border = element_rect(fill = NA, colour = "black"),
        axis.line.y.right = element_blank(),
        axis.text.y.right = element_blank(),
        axis.ticks.y.right = element_blank(),legend.position = "none")

#################################Fig.S3F
main_gen_2<-iNEXT4steps(continent_gen,q = seq(0, 2, 0.2),datatype = "incidence_freq")

########################################################################################################## aquatic environments
water_gen<-read.csv("water_gen.csv",header = T)
richness_water_gen<-iNEXT(water_gen,q=0,datatype = "incidence_freq")

#################################Fig.S3G
gg.water_gen1<-ggiNEXT(richness_water_gen,type = 1,se=T,color.var = "Assemblage", grey=FALSE)+
  theme_classic()+
  geom_hline(yintercept = 112.22, linetype="dotdash", colour="#cc79a7",size=1.5)+ ## river
  geom_hline(yintercept = 121.841 , linetype="dotdash", colour="#0072b2",size=1.5)+  ##Coast
  geom_hline(yintercept = 815.85714  , linetype="dotdash", colour="#d55e00",size=1.5)+ ##Bay
  #geom_hline(yintercept = 41   , linetype="dotdash", colour="#009e73",size=1.5)+ ##Sea
  labs(y="Genus richness")+
  labs(x="Number of sampling sites")+
  theme(text = element_text(size = 25, family="serif"),
        axis.text = element_text(size = 23, family="serif",color = 'black'),
        panel.border = element_rect(fill = NA, colour = "black",size = 1),
        axis.line.y.right = element_blank(),
        axis.text.y.right = element_blank(),
        axis.ticks.y.right = element_blank(),legend.position = "none")+
  scale_y_break(c(150,810),ticklabels=c(820))+
  ylim(0,820)

#################################Fig.S3H
gg.water_gen2<-ggiNEXT(richness_water_gen,type = 2,se=T,color.var = "Assemblage", grey=FALSE)+
  theme_classic()+
  labs(x="Number of sampling sites")+
  theme(text = element_text(size = 25, family="serif"),
        axis.text = element_text(size = 23, family="serif",color = 'black'),
        panel.border = element_rect(fill = NA, colour = "black"),
        axis.line.y.right = element_blank(),
        axis.text.y.right = element_blank(),
        axis.ticks.y.right = element_blank(),legend.position = "none")

#################################Fig.S3I
main_gen_3<-iNEXT4steps(water_gen,q = seq(0, 2, 0.2),datatype = "incidence_freq")
