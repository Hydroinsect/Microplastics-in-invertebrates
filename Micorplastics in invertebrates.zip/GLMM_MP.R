library(lme4)
library(glmm.hp)
library(MCMCglmm)
library(MuMIn)

method<-read.csv("method.csv", header = T)

#################################################### Env
glmerenv<- lmer(log(MP)~Environment2+(1|score2)+(1|Abund),data=method)
summary(glmerenv)
aic1 <- AIC(logLik(glmerenv))
aic1
mcmc <- MCMCglmm(fixed=log(MP)~Environment2,random=~score2+Abund+Abund, data = method) # estimating p value for correlated random effects 
summary(mcmc) 
r.squaredGLMM(glmerenv)
#################################################### N
glmerN<- lmer(log(MP)~N+(1|score2)+(1|Abund), data=method)
summary(glmerN)
aic1 <- AIC(logLik(glmerN))
aic1
mcmc <- MCMCglmm(fixed=log(MP)~Environment2,random=~score2+Abund, data = method) # estimating p value for correlated random effects 
summary(mcmc) 
r.squaredGLMM(glmerN)
#################################################### E
glmerE<- lmer(log(MP)~E+(1|score2)+(1|Abund), data=method)
summary(glmerE)
aic1 <- AIC(logLik(glmerE))
aic1
mcmc <- MCMCglmm(fixed=log(MP)~Environment2,random=~score2+Abund, data = method) # estimating p value for correlated random effects 
summary(mcmc) 
r.squaredGLMM(glmerE)

####################################traits
############################## x10**
glmer2<- lmer(log(MP)~x10+(1|score2)+(1|Abund), data=method)
summary(glmer2)
aic2 <- AIC(logLik(glmer2))
aic2
mcmc <- MCMCglmm(fixed=log(MP)~x10,random=~score2+Abund, data = method) # estimating p value for correlated random effects 
summary(mcmc) 
r.squaredGLMM(glmer2)
############################## x11**
glmerx11<- lmer(log(MP)~x11+(1|score2)+(1|Abund), data=method)
summary(glmerx11)
aicx11 <- AIC(logLik(glmerx11))
aicx11
mcmc <- MCMCglmm(fixed=log(MP)~x11,random=~score2+Abund, data = method) # estimating p value for correlated random effects 
summary(mcmc) 
r.squaredGLMM(glmerx11)

######### x21
glmerx21<- lmer(log(MP)~x21+(1|score2)+(1|Abund), data=method)
summary(glmerx21)
aicx21 <- AIC(logLik(glmerx21))
aicx21
mcmc <- MCMCglmm(fixed=log(MP)~x21,random=~score2+Abund, data = method) # estimating p value for correlated random effects 
summary(mcmc) 
r.squaredGLMM(glmerx21)

######### x101
glmerx101<- lmer(log(MP)~x101+(1|score2)+(1|Abund), data=method)
summary(glmerx101)
aicx101 <- AIC(logLik(glmerx101))
aicx101
mcmc <- MCMCglmm(fixed=log(MP)~x101,random=~score2+Abund, data = method) # estimating p value for correlated random effects 
summary(mcmc) 
r.squaredGLMM(glmerx101)

######### x201
glmerx201<- lmer(log(MP)~x201+(1|score2)+(1|Abund), data=method)
summary(glmerx201)
aicx201 <- AIC(logLik(glmerx201))
aicx201
mcmc <- MCMCglmm(fixed=log(MP)~x201,random=~score2+Abund, data = method) # estimating p value for correlated random effects 
summary(mcmc) 
r.squaredGLMM(glmerx201)

######### x500
glmerx500<- lmer(log(MP)~x500+(1|score2)+(1|Abund), data=method)
summary(glmerx500)
aicx500 <- AIC(logLik(glmerx500))
aicx500
mcmc <- MCMCglmm(fixed=log(MP)~x500,random=~score2+Abund, data = method) # estimating p value for correlated random effects 
summary(mcmc) 
r.squaredGLMM(glmerx500)

############################################### *****Shredder
glmerShredder<- lmer(log(MP)~Shredder+(1|score2)+(1|Abund), data=method)
summary(glmerShredder)
aicShredder <- AIC(logLik(glmerShredder))
aicShredder
mcmc <- MCMCglmm(fixed=log(MP)~Shredder,random=~score2+Abund, data = method) # estimating p value for correlated random effects 
summary(mcmc) 
r.squaredGLMM(glmerShredder)

######### Herbivore
glmerHerbivore<- lmer(log(MP)~Herbivore+(1|score2)+(1|Abund), data=method)
summary(glmerHerbivore)
aicHerbivore <- AIC(logLik(glmerHerbivore))
aicHerbivore
mcmc <- MCMCglmm(fixed=log(MP)~Herbivore,random=~score2+Abund, data = method) # estimating p value for correlated random effects 
summary(mcmc) 
r.squaredGLMM(glmerHerbivore)

######### Predator
glmerPredator<- lmer(log(MP)~Predator+(1|score2)+(1|Abund), data=method)
summary(glmerPredator)
aicPredator <- AIC(logLik(glmerPredator))
aicPredator
mcmc <- MCMCglmm(fixed=log(MP)~Predator,random=~score2+Abund, data = method) # estimating p value for correlated random effects 
summary(mcmc) 
r.squaredGLMM(glmerPredator)

######### Parasite
glmerParasite<- lmer(log(MP)~Parasite+(1|score2)+(1|Abund), data=method)
summary(glmerParasite)
aicParasite <- AIC(logLik(glmerParasite))
aicParasite
mcmc <- MCMCglmm(fixed=log(MP)~Parasite,random=~score2+Abund, data = method) # estimating p value for correlated random effects 
summary(mcmc) 
r.squaredGLMM(glmerParasite)

######### Surface_deposit
glmerSurface_deposit<- lmer(log(MP)~Surface_deposit+(1|score2)+(1|Abund), data=method)
summary(glmerSurface_deposit)
aicSurface_deposit <- AIC(logLik(glmerSurface_deposit))
aicSurface_deposit
mcmc <- MCMCglmm(fixed=log(MP)~Surface_deposit,random=~score2+Abund, data = method) # estimating p value for correlated random effects 
summary(mcmc) 
r.squaredGLMM(glmerSurface_deposit)

######### Suspension
glmerSuspension<- lmer(log(MP)~Suspension+(1|score2)+(1|Abund), data=method)
summary(glmerSuspension)
aicSuspension <- AIC(logLik(glmerSuspension))
aicSuspension
mcmc <- MCMCglmm(fixed=log(MP)~Suspension,random=~score2+Abund, data = method) # estimating p value for correlated random effects 
summary(mcmc) 
r.squaredGLMM(glmerSuspension)

######### Scavenger
glmerScavenger<- lmer(log(MP)~Scavenger+(1|score2)+(1|Abund), data=method)
summary(glmerScavenger)
aicScavenger <- AIC(logLik(glmerScavenger))
aicScavenger
mcmc <- MCMCglmm(fixed=log(MP)~Scavenger,random=~score2+Abund, data = method) # estimating p value for correlated random effects 
summary(mcmc) 
r.squaredGLMM(glmerScavenger)

